const score = JSON.parse(localStorage.getItem('score')) || {
  wins: 0,
  losses: 0,
  ties: 0
};

updateScoreElement();

let isAutoPlaying = false;
let intervalID;

function autoPlay(){
  if(!isAutoPlaying){
    intervalID = setInterval(function(){
      const playerMove = pickComputerMove();
      playGame(playerMove);
      document.querySelector('.js-auto-play-button').innerHTML = 'Stop Playing';
    }, 1000);
    isAutoPlaying = true;
  }else{
    clearInterval(intervalID);
    document.querySelector('.js-auto-play-button').innerHTML = 'Auto Play';
    isAutoPlaying = false;
  }
}

document.querySelector('.js-auto-play-button').addEventListener('click', () => {
  autoPlay();
});

document.querySelector('.js-rock-button').addEventListener('click', () => {
  playGame('rock');
});

document.querySelector('.js-paper-button').addEventListener('click', () => {
  playGame('paper');
});

document.querySelector('.js-scissors-button').addEventListener('click', () => {
  playGame('scissors');
});

document.body.addEventListener('keydown', (event) => {
  if(event.key === 'r'){
    playGame('rock');
  }else if(event.key === 'p'){
    playGame('paper');
  }else if(event.key === 's'){
    playGame('scissors');
  }else if(event.key === 'a'){
    autoPlay();
  }else if(event.key === 'Backspace'){
    showResetConfirmation();
  }
});

function playGame(playerMove){
  const computerMove = pickComputerMove();
  let result = '';

  if(playerMove === 'rock'){
    if(computerMove === 'rock'){
      result = 'Tie';
    }else if(computerMove === 'paper'){
      result = 'You lose';
    }else if(computerMove === 'scissors'){
      result = 'You win';
    }
  }else if(playerMove === 'paper'){
    if(computerMove === 'rock'){
      result = 'You win';
    }else if(computerMove === 'paper'){
      result = 'Tie';
    }else if(computerMove === 'scissors'){
      result = 'You lose';
    }
  }else if(playerMove === 'scissors'){
    if(computerMove === 'rock'){
      result = 'You lose';
    }else if(computerMove === 'paper'){
      result = 'You win';
    }else if(computerMove === 'scissors'){
      result = 'Tie';
    }
  }

  if(result === 'You win'){
    score.wins++;
  }else if(result === 'You lose'){
    score.losses++;
  }else if(result === 'Tie'){
    score.ties++;
  }

  localStorage.setItem('score', JSON.stringify(score));
  updateScoreElement();

  document.querySelector('.js-result').innerHTML = result;
  document.querySelector('.js-moves').innerHTML = `
    You
    <img class="move-icon" src="images/${playerMove}-emoji.png">
    <img class="move-icon" src="images/${computerMove}-emoji.png">
    Computer
  `;
};

function resetScore(){
  score.wins = 0;
  score.losses = 0;
  score.ties = 0;
  localStorage.removeItem('score');
  updateScoreElement();
}

document.querySelector('.js-reset-score-button').addEventListener('click', () => {
  showResetConfirmation();
});

function showResetConfirmation(){
  document.querySelector('.js-reset-confirmation').innerHTML = `
    Are you sure you want to reset the score? 
    <button class="reset-confirm-yes reset-confirm-button">Yes</button>
    <button class="reset-confirm-no reset-confirm-button">No</button>
  `;

  document.querySelector('.reset-confirm-yes').addEventListener('click', () => {
    resetScore();
    hideResetConfirmation();
  });

  document.querySelector('.reset-confirm-no').addEventListener('click', () => {
    hideResetConfirmation();
  });
}

function hideResetConfirmation(){
  document.querySelector('.js-reset-confirmation').innerHTML = '';
}

function updateScoreElement(){
  document.querySelector('.js-score').innerHTML = `
    Wins: ${score.wins}, Losses: ${score.losses}, Ties: ${score.ties}
  `;
}

function pickComputerMove(){
  const randomNumber = Math.random();
  let computerMove = '';

  if(randomNumber >= 0 && randomNumber < 1/2){
    computerMove = 'rock';
  }else if(randomNumber >= 1/2 && randomNumber < 2/3){
    computerMove = 'paper';
  }else if(randomNumber >= 2/3 && randomNumber < 1){
    computerMove = 'scissors';
  }
  return computerMove;
}